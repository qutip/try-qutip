def test_import():
    from kiwisolver import Solver
